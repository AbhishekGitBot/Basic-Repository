/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    float num1,num2,sum,avg;
    cout<<"enter two nmubers: ";
    cin>>num1;
    cin>>num2;
    
    sum=num1+num2;
    avg=sum/2;
    
    cout<<"Sum = " <<sum<<"\n";
    cout<<"avg = " <<avg<<"\n";

    return 0;
}