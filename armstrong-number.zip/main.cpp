/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a,sum=0;
    cout<<"enter a number ";
    cin>>a;
    int last=1;
    while(a>0)
    {
        last=a%10;
        sum=sum+last*last*last;
        a=a/10;
    }
    if(sum==a)
    {
        cout<<"this is an armstrong number";
    }
    else
    {
        cout<<"this is not an armastrong";
    }
    return 0;
}