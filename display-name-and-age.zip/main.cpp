/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
class person
{
    char name[30];
    int age;
    
    public:
    void getdata(void);
    void display(void);
};
void person ::getdata(void)
{
    cout<<"enter name: ";
    cin>>name;
    cout<<"enter age: ";
    cin>>age;
}
void person::display(void)
{
    cout<<"\nname: " << name;
    cout<<"\nage: " << age;
}
int main()
{
    person p;
    p.getdata();
    p.display();
    
    return 0;
}
    
