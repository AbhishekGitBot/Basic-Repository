/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int count=0,a,b,i;
    cout<<"enter lower limit: ";
    cin>>a;
    cout<<"enter upper limit: ";
    cin>>b;
    for(a;a<=b;a++)
    {
        for(i=2;i<=a/2;i++)
        {
            if(a%i==0)
            {
                count++;
            }
        }
    }
        if(count<=0)
        {
            cout<<a;
        }
    return 0;
}




