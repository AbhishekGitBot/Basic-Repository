/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a,i,j,k;
    for(a=1;a<=5;a++)
    {
        for(i=4;i>=a;i--)
        {
            cout<<" ";
        }
            for(j=1;j<=a;j++)
            {
                cout<<"*";
            }
                for(k=2;k<=a;k++)
                {
                    cout<<"*";
                }
        cout<<endl;
    }

    return 0;
}