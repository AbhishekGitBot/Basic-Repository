#include<iostream>
using namespace std;
int main()
{
    int n1,n2,n3;
    cout<<"enter any three numbers:";
    cin>>n1>>n2>>n3;
    if(n1>=n2&&n1>=n3)
    cout<<"largest number is:"<<n1;
    if(n2>=n1&&n2>=n3)
     cout<<"largest number is:"<<n2;
     else
     cout<<"largest number is:"<<n3;
     return 0;
}
