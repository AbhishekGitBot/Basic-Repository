/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a,b=2,c=1;
    cout<<"enter value of a: ";
    cin>>a;
    for(b;b<a;b++)
    {
        if(a%b==0)
        {
          c++;  
        }
    }
        if(c>1)
        {
            cout<<"a is a composite num";
        }
        else if(a<=1)
        {
            cout<<"invalid";
        }
        else
        {
            cout<<"a is a prime num";
        }
return 0;
}
